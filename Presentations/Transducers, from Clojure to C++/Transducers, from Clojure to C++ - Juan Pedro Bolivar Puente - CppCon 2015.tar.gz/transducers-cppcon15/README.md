> ```
> git submodule update --recursive --init
> ```

> ```
> cd reveal
> npm install
> bower install
> grunt
> ```
